# TNT TOOL — Free Starter

Bản frontend tĩnh để thử giao diện TNT TOOL trên iPhone Safari.

## Có gì?
- Giao diện Dark Premium (đen/vàng), tối ưu điện thoại.
- Thanh điều hướng dưới: Tổng quan, Lịch, Nhật ký, Tài khoản.
- Tạo lịch nhắc mẫu; lịch được lưu trong bộ nhớ trình duyệt.
- Nhật ký giao diện mẫu.
- Trang đăng nhập/mã kích hoạt chỉ là giao diện minh họa.

## Giới hạn
- Chưa có backend, đăng nhập thật hoặc mã kích hoạt thật.
- Không nhập mật khẩu thật vào bản demo.
- Lịch chưa gửi thông báo nền khi đóng Safari.
- Không có chức năng điều khiển/tự động hóa trò chơi.

## Đưa lên website miễn phí
Có thể tải `index.html` lên một repository GitHub rồi bật GitHub Pages. Xem hướng dẫn từng bước trong cuộc trò chuyện trước khi thao tác.
